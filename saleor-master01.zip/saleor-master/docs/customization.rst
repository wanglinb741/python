Customizing Saleor
==================

.. toctree::
   :maxdepth: 1

   customization/docker
   customization/templates
   customization/emails
   customization/frontend
   customization/backend
   customization/i18n
   customization/tests
   customization/ci
   customization/pypy
