Saleor
======

An open source storefront written in Python.

Contents:

.. toctree::
   :maxdepth: 2

   gettingstarted
   customization
   payment-gateways
   contributing
   architecture
   integrations
   deployment
   guides


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
