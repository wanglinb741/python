Guides
======

.. toctree::
   :maxdepth: 2

   guides/orders
   guides/payments
   guides/navigation
   guides/taxes
   guides/recaptcha
   guides/email_integration
