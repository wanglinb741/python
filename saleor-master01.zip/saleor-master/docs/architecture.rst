Architecture
============

.. toctree::
   :maxdepth: 1

   architecture/money
   architecture/products
   architecture/thumbnails
   architecture/stock
   architecture/orders
   architecture/events
   architecture/i18n
   architecture/translations
   architecture/search
   architecture/payments
   architecture/shippings
   architecture/settings
   architecture/page
   architecture/gdpr
   architecture/graphql
