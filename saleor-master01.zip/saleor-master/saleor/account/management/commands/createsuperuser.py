from django.contrib.auth.management.commands.createsuperuser import Command

__all__ = ['Command']
